package com.CS1.OnlineContactManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineContactManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
